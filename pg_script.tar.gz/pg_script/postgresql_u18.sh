#!/bin/bash
# Author: kienlt
# Automation install postgresql with defined config file

# Password for user postgres
POSTGRES_PASS=KJwY6ZDoobTnj5gUcrDz

CONFIG_FILE='/etc/postgresql/12/main/postgresql.conf'
ARCHIVEDIR_PATH='/var/lib/postgresql/12/archivedir'
ARCHIVE_CMD="archive_command = 'test ! -f ${ARCHIVEDIR_PATH}/%f && cp %p ${ARCHIVEDIR_PATH}/%f'"

# Install required
apt-get install wget -y

# Install postgresql
apt-get update
sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
apt-get install postgresql -y

# Copy optimized setting files
cp postgresql.conf /etc/postgresql/12/main/
# Restart service
service postgresql restart

# Change postgres user password
sudo -u postgres psql -U postgres -d postgres -c "alter user postgres with password '$POSTGRES_PASS';"

if [ ! -d $ACHIVEDIR_PATH ]; then
  mkdir -p $ARCHIVEDIR_PATH
  chown -R postgres: $ARCHIVEDIR_PATH
fi

if  ! grep "test ! -f" $CONFIG_FILE ; then
  echo $ARCHIVE_CMD >> $CONFIG_FILE 
fi
